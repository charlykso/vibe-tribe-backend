export {};
//# sourceMappingURL=firebase-test-simple.d.ts.map