export {};
//# sourceMappingURL=firebase-test.d.ts.map