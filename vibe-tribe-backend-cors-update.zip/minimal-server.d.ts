declare const app: import("express-serve-static-core").Express;
export { app };
//# sourceMappingURL=minimal-server.d.ts.map