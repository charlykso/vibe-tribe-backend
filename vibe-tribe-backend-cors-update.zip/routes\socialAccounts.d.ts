declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=socialAccounts.d.ts.map