declare const setupFirebase: () => Promise<void>;
export default setupFirebase;
//# sourceMappingURL=migrate.d.ts.map