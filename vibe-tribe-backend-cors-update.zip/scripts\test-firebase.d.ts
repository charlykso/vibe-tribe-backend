declare const testFirebaseConnection: () => Promise<void>;
export default testFirebaseConnection;
//# sourceMappingURL=test-firebase.d.ts.map