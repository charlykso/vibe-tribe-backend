declare const app: import("express-serve-static-core").Express;
export { app };
//# sourceMappingURL=test-server.d.ts.map